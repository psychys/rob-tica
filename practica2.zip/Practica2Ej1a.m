TextOut(0,LCD_LINE1,'-- Ejercicio 2a--');
TextOut(0,LCD_LINE2,'Presione el boton central para');
TextOut(0,LCD_LINE3,'comenzar con la prueba');
while(~ButtonPressed(BTNCENTER))
    % Esperamos a que se pulse el boton central
end 
ClearScreen();

t_ini = CurrentTick();     % Obtiene el tiempo de simulacion actual
SetSensorLight(IN_1);      % Inicia el sensor de luz
SetSensorUltrasonic(IN_2); % Inicial el sonar
ResetRotationCount(OUT_A); % Establece a 0 los encoder de los dos motores
ResetRotationCount(OUT_C); % A izquierda, C derecha

OnFwd(OUT_AC,41); % Arranca ambos motores con potencia = 41

tiempo = 2000; % Tiempo en milisegundos que debe durar el programa

while((CurrentTick()-t_ini) <= tiempo)
    
    t = CurrentTick()-t_ini;
    
    ra = MotorRotationCount(OUT_A); % Lee el encoder del motor izquierdo
    rc = MotorRotationCount(OUT_C); % Lee el encoder del motor derecho
    TextOut(1,LCD_LINE4,strcat('Deg A: ',num2str(ra)));
    TextOut(1,LCD_LINE5,strcat('Deg C: ',num2str(rc)));
    
    Wait(50); % Espera 50 ms para continuar, haciendo que este sea el periodo
              % de ejecucion del bucle
end

Off(OUT_AC); % Detiene los motores
TextOut(1,LCD_LINE7,'--The end--');
Wait(5000);